"""Top‑level package for UART‑CL Python port."""
__all__ = [
    "serial_io",
    "error_db",
    "nor"
]
__version__ = "0.1.0"
